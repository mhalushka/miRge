import os
import imp
from distutils.spawn import find_executable


def checkModules():
	modules = ['cutadapt', 'Bio', 'sklearn', 'numpy', 'scipy', 'pandas', 'reportlab', 'forgi']
	for each in modules:
		try:
			imp.find_module(each)
		except ImportError:
			if not find_executable('pip'):
				print 'In order to install the required modules quickly, please install pip'
				return None
			else:
				os.system('pip install %s'%(each))
		finally:
			print 'Required modules: %s is installed.'%(each)

if __name__ == '__main__':
	checkModules()